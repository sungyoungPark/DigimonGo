package example.asus.digimongo;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class DamagochiFragment extends Fragment {

    ImageView mImage;
    ImageView background;
    float x= 10;
    int count = 0;
    int i;

    private OnFragmentInteractionListener mListener;

    public DamagochiFragment() {
        // Required empty public constructor
    }

    public static DamagochiFragment newInstance() {
     return new DamagochiFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final ViewGroup damagochiView = (ViewGroup) inflater.inflate(R.layout.fragment_damagochi, container, false);

        mImage = damagochiView.findViewById(R.id.mImage);
        onThreadStart();

        return  damagochiView;
    }

    Handler handler = new Handler(){
        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void handleMessage(Message msg) {
            updateThread();
            horintalMove();
        }
    };

    Handler handler2 = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            // horintalMove();
        }
    };


     void onThreadStart() {
        Thread myThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try{
                        handler.sendMessage(handler.obtainMessage());
                        Thread.sleep(1000);
                    }catch(Throwable t){}
                }
            }
        });
        myThread.start();

        Thread myThread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try{
                        handler2.sendMessage(handler.obtainMessage());
                        Thread.sleep(1000);
                    }catch(Throwable t){}
                }
            }
        });
        myThread2.start();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void updateThread(){


        int mod = i%3;
        switch(mod){
            case 0:
                i++; mImage.setImageDrawable(getResources().getDrawable(R.drawable.monster1, null));
                break;
            case 1:
                i++; mImage.setImageDrawable(getResources().getDrawable(R.drawable.monster2, null));
                break;
            case 2:
                i=0; mImage.setImageDrawable(getResources().getDrawable(R.drawable.monster3, null));
                break;
        }
    }
    public void horintalMove(){
        if(count<5) {
            count+=1;
            x+=20;
            mImage.setX(x);
        }
        else if(count<15) {
            count+=1;
            x-=20;
            mImage.setX(x);
        }
        else count=0;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

    }



}
