package example.asus.digimongo;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    FragmentTransaction fragmentTransaction ;
    LoginFragment loginFragment;
    Fragment currentFragment;
    Bundle bundle;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    int loginflag=0;    //로그인 flag

    Intent intent;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    /*    this.requestWindowFeature(Window.FEATURE_NO_TITLE);*/
       setContentView(R.layout.activity_main);

       currentFragment = getFragmentManager().findFragmentById(R.id.loginFrame);  //현재 프레그먼트 갖고 오기

       mAuth=FirebaseAuth.getInstance();

       mAuthListener=new FirebaseAuth.AuthStateListener() {
           @Override
           public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
               FirebaseUser user=firebaseAuth.getCurrentUser();

               if(user!=null){
                   Log.d("5525","onAuthStateChanged: signed_in: "+user.getUid());
               }
               else {
                   Log.d("5525","onAuthStateChanged: signed out");
               }
           }
       };

       loginFragment=new LoginFragment();
        LinearLayout openingScreen=findViewById(R.id.openingScreen);
        openingScreen.setOnTouchListener(new View.OnTouchListener() {
                @Override
            public boolean onTouch(View v, MotionEvent event) {   //화면을 누르면 로그인 프레그먼트생성, 로그인 화면으로 넘어감
                        //Toast.makeText(getApplicationContext(), "눌림", Toast.LENGTH_LONG).show();
                        if(loginflag==0) {
                            fragmentTransaction = getFragmentManager().beginTransaction();
                            fragmentTransaction.replace(R.id.loginFrame, loginFragment);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                        }
                return true;
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mAuthListener!=null)
            mAuth.removeAuthStateListener(mAuthListener);
    }


   public void correctID(String email, String password){   //서버와 로그인
      // final int[] flag = {0};
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Log.e("3838","signInwithEmail:success",task.getException());
                            Toast.makeText(MainActivity.this,"Authentication success.",Toast.LENGTH_LONG).show();
                            loginflag=1;
                            Fragment fg=DamagochiFragment.newInstance();
                            setChildFragment(fg);
                        }

                        else{
                            Log.e("3838","signInWithEmali:failed",task.getException());
                            Toast.makeText(MainActivity.this,"Authenticaation failed.",Toast.LENGTH_LONG).show();

                        }
                    }
                });
        Log.d("3838",""+loginflag);
    }

    public void signUp(String email, String password){
        Log.d("3838", "버튼 눌림222");
        if(email==null ||password==null){
            Toast.makeText(this,"빈칸을 채우시오",Toast.LENGTH_SHORT).show();
        }
        else{
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(!task.isSuccessful()){
                        Toast.makeText(MainActivity.this,"회원가입 실패",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this,"회원가입 성공",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void setChildFragment(Fragment child){
        FragmentTransaction childFrag=getFragmentManager().beginTransaction();
        childFrag.replace(R.id.loginFrame,child);
        childFrag.commit();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

}
